package jardinbotanico;

public class PlantaRepetidaException extends RuntimeException{
    private static final String MESSAGE = "Esta planta ya se encuentra en la lista";

    public PlantaRepetidaException() {
        super(MESSAGE);
    }

}
