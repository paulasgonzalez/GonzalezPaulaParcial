package jardinbotanico;


public class Arbusto extends Planta implements Podable{
    private int densidad;

    public Arbusto(String nombre, String ubicacionJardin, String climaProspera, int densidad) {
        super(nombre, ubicacionJardin, climaProspera);
        this.densidad = densidad;
    }
    
    @Override
    public void podar() {
        System.out.println("El " + getNombre() + " ha sido podado" );    
    }

    @Override
    public String toString() {
        return "Arbusto{" + "nombre = " + getNombre() + ", ubicacionJardin = " + getUbicacion() +", climaProspera = " + getClima() + ", densidad = " + densidad + '}';
    }
    
    
    
    
    
    
}
