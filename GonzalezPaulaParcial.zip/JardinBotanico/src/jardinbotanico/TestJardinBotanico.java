package jardinbotanico;

public class TestJardinBotanico {

    public static void main(String[] args) {
        
        Jardin j = new Jardin();
        
        Arbol a1 = new Arbol("Roble", "Fondo", "Seco", 20.0);
        
        // cambian unicamente la ubicacion para chequear el equals
        //(para que sea repetido debe ser igual el nombre y la ubicacion)
        Arbusto ar1 = new Arbusto("Rosal", "Frente", "Lluvioso", 8);
        Arbusto ar2 = new Arbusto("Rosal", "Fondo", "Lluvioso", 9);
        
        // f1 y f2 son iguales, prueba la excepcion PlantaRepetidaException
        Flor f1 = new Flor("Jazmin", "Medio", "Soleado", TemporadaFlorecimiento.PRIMAVERA);
        Flor f2 = new Flor("Jazmin", "Medio", "Soleado", TemporadaFlorecimiento.PRIMAVERA);
        
        
        try{
            j.agregarPlanta(a1);
            j.agregarPlanta(ar1);
            j.agregarPlanta(ar2);
            j.agregarPlanta(f1);
            //f2 esta repetida, lanzara una excepcion
            j.agregarPlanta(f2);
            
        } 
        catch(NullPointerException ex){
            System.out.println(ex.getMessage());
        }
        catch(PlantaRepetidaException ex){
            System.out.println(ex.getMessage());
        }
        
        System.out.println("-----------------------------");
        j.mostrarPlantas();
        
        System.out.println("-----------------------------");
        j.podarPlantas();
        
        
        
        
    }
    
}
