package jardinbotanico;


public abstract class Planta {
    private String nombre;
    private String ubicacionJardin;
    private String climaProspera;

    public Planta(String nombre, String ubicacionJardin, String climaProspera) {
        this.nombre = nombre;
        this.ubicacionJardin = ubicacionJardin;
        this.climaProspera = climaProspera;
    }
    
    public boolean equals(Object o){
        if (this == o){
            return true;
        }
        if (o == null || this.getClass() != o.getClass()){
            return false;
        }
        
        Planta other = (Planta) o;
        return nombre.equals(other.nombre) && ubicacionJardin.equals(other.ubicacionJardin);
    }

    
    protected String getNombre(){
        return nombre;
    }
    
    protected String getUbicacion(){
        return ubicacionJardin;
    }
    
    protected String getClima(){
        return climaProspera;
    }

    
    
    
    
    
    
        
}        
        
        
        
        
        
    
    

