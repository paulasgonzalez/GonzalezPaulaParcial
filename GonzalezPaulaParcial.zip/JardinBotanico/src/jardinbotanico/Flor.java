package jardinbotanico;


public class Flor extends Planta{
    private TemporadaFlorecimiento temporada;

    public Flor(String nombre, String ubicacionJardin, String climaProspera, TemporadaFlorecimiento temporada) {
        super(nombre, ubicacionJardin, climaProspera);
        this.temporada = temporada;
    }

    @Override
    public String toString() {
        return "Flor{" + "nombre = " + getNombre() + ", ubicacionJardin = " + getUbicacion() +", climaProspera = " + getClima() + ", temporada = " + temporada + '}';
    }
    
    
}
