package jardinbotanico;

import java.util.ArrayList;
import java.util.List;


public class Jardin {
    private List <Planta> plantas;

    public Jardin() {
        plantas = new ArrayList<>();
    }
    
    public void agregarPlanta(Planta p){
        if(p == null){
            throw new NullPointerException("Esto no es una planta, es un null");
        }
        if(plantas.contains(p)){
            throw new PlantaRepetidaException();
        }
        plantas.add(p);
    }
    
    public void mostrarPlantas(){
        if(plantas.isEmpty()){
            System.out.println("No hay plantas para mostrar");
        }
        for(Planta p: plantas){
            System.out.println(p);
        }
    }
    
    public void podarPlantas(){
        for(Planta p: plantas){
            if (p instanceof Podable pod){
                pod.podar();
            }
            else{
                System.out.println(p + ": ADVERTENCIA! esta planta no puede ser podada");
            }
        }
    }
    
    
    
    
    
}
