package jardinbotanico;


public class Arbol extends Planta implements Podable{
    private double alturaMax;

    public Arbol(String nombre, String ubicacionJardin, String climaProspera, double alturaMax) {
        super(nombre, ubicacionJardin, climaProspera);
        this.alturaMax = alturaMax;
    }

    @Override
    public void podar() {
        System.out.println("El " + getNombre() + " ha sido podado" );
    }

    @Override
    public String toString() {
        return "Arbol{" + "nombre = " + getNombre() + ", ubicacionJardin = " + getUbicacion() +", climaProspera = " + getClima() + ", alturaMax = " + alturaMax + '}';
    }

    

    
    
    
    
    
    
}
