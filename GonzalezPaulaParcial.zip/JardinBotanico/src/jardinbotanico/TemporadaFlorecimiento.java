package jardinbotanico;

public enum TemporadaFlorecimiento {
    PRIMAVERA,
    VERANO,
    OTONIO,
    INVIERNO
    
}
